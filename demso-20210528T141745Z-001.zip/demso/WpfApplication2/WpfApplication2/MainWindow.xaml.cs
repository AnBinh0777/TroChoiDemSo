﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        int[] a;
        int n;
        int spt = 0;
        string s;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void txtsophantu_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnsophantu_Click(object sender, RoutedEventArgs e)
        {
            n = int.Parse(txtnhapsophantu.Text);
            a = new int[n];
            txtnhapsophantu.IsEnabled = false;
            btnsophantu.IsEnabled = false;
        }

        private void btnnhap_Click(object sender, RoutedEventArgs e)
        {
            if (spt < n)
            {
                a[spt] = int.Parse(txtketqua.Text);
                spt++;
            }
            txtketqua.Text = "";
        }

        private void btnxuat_Click(object sender, RoutedEventArgs e)
        {
            for(int i = 0;i<n;i++)
            {
                s = s + " " + a[i];
            }
            txtxuatsophantu.Text = s;
        }

        private void txtketqua_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtxuatsophantu_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnmax_Click(object sender, RoutedEventArgs e)
        {
            int max = 0;
            for(int i = 0; i <spt;i++)
            {
                if (a[i] > max)
                {
                     max = a[i];
                }
                txtxuatsophantu.Text = "" + max;
            }
        }

        private void btnmin_Click(object sender, RoutedEventArgs e)
        {
            int min = 999999999;
            for (int i = 0; i < spt; i++)
            {
                if (a[i] < min)
                {
                    min = a[i];
                }
                txtxuatsophantu.Text = "" + min;
            }

        }

        private void txttim_Click(object sender, RoutedEventArgs e)
        {
            int x = int.Parse(txtsocantim.Text);
            int dem = 0;
            for(int i = 0;  i < spt ; i++)
            {
                if(a[i] == x)
                {
                    dem++;
                }
            }
            txtxuatsophantu.Text = "so " + x + " xuat hien " + dem + " lan";
        }

        private void txtsocantim_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
